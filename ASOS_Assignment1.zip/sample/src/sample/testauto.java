package sample;
import java.io.File;
//import org.apache.http.NameValuePair
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.apache.commons.io.FileUtils;

/*Feature : Use the website to find shirts
        So that I can order a shirt
        As a customer
        I want to be able to find t shirts
    Scenario: Search for t shirts
        Given I want to order a shirt
        When I search for purple t shirts
        Then I should see some purple t shirts*/


//Scenario1: Search_for_T_Shirts

public class testauto {
	public static void main(String args[]) throws InterruptedException {
	//System.setProperty("webdriver.gecko.driver", "C:\\Users\\selenium\\geckodriver.exe");

	WebDriver driver = new FirefoxDriver();
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	
					
	//Given I want to order a shirt in ASOS website
		driver.get("http://www.asos.com");
	    //click ok for cookies
	    driver.findElement(By.id("btnClose")).click();

								
	//search for purple t shirt
	
	WebElement webElement = driver.findElement(By.id("txtSearch"));
	webElement.sendKeys("Purple T-Shirt");
	driver.findElement(By.className("go")).click();
	
	//Then("^I should see some purple t shirts$")
	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	List<WebElement> lstProductsName=driver.findElements(By.cssSelector("ul > li.product-container.interactions"));
	    	for(WebElement eleDes:lstProductsName){
	    		 				    	
				System.out.println(eleDes.getText());
				String str =eleDes.getText(); 
				if(str.contains("Purple"))
					
				try{
				System.out.println("Test Passes");
				}
				catch (Throwable e)
				{
				
				System.out.println("Test Failed");	
				}
	    		
				Assert.assertTrue(str.contains("Purple"));
				    	
	    	}
	    	
File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	             //The below method will save the screen shot in d drive with name "screenshot.png"
	                try{
	                	FileUtils.copyFile(scrFile, new File("screenshot-purple-tshirt.png"));
						}
						catch (Throwable e)
						{
						
						System.out.println("Output file saving failed");	
						}
	                
	        
}

}


